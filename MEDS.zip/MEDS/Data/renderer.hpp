// Contains data for a renderer.
// Contains functions to get and set transform information.

#pragma once

namespace Engine {
    class DataManager;
    class Data;
    // 0: unsigned int      frame index
    // 1: float             alpha
    // 2: sprite_source*    sprite_source
    // 3: vertex_list*      mesh

    class Renderer {
        public:
            // Creates a new renderer data on the heap.
            static Data* New();

        private:
            static DataManager* manager;

            // Loop functions.
            static void update(Data&, float);
    };
}
