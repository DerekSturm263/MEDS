// Contains data for movement.
//

#pragma once

namespace Engine {
    class DataManager;
    class Data;

    class Movement {
        public:
            // Creates a new movement data on the heap.
            static Data* New();

        private:
            static DataManager* manager;

            // Loop functions.
            static void update(Data&, float);
    };
}
