#include "physics.hpp"
#include "transform.hpp"
#include "../Entities/data.hpp"
#include "../Entities/entity.hpp"
#include "../Systems/debug.hpp"
#include "../Managers/data_manager.hpp"

namespace Engine {
    DataManager* Physics::manager = nullptr;

    Data* Physics::New() {
        if (!manager) {
            manager = new DataManager(0, nullptr, update, nullptr);
        }

        glm::vec2 zero_v = glm::vec2(0, 0);
        float zero_f = 0;

        Data* data = new Data(5, &zero_v, &zero_v, &zero_v, &zero_f, &zero_f);
        manager->add_data(data);
        return data;
    }

    glm::vec2 const&   Physics::get_old_pos(Data const& data)        { return *(glm::vec2*)  data.read(0);   }
    glm::vec2 const&   Physics::get_acc(Data const& data)            { return *(glm::vec2*)  data.read(1);   }
    glm::vec2 const&   Physics::get_vel(Data const& data)            { return *(glm::vec2*)  data.read(2);   }
    float const&       Physics::get_inv_mass(Data const& data)       { return *(float*)      data.read(3);   }
    float const&       Physics::get_rot_vel(Data const& data)        { return *(float*)      data.read(4);   }

    void Physics::set_old_pos(Data& data, glm::vec2 const& old_pos)  { data.write(0, &old_pos);              }
    void Physics::set_acc(Data& data, glm::vec2 const& acc)          { data.write(1, &acc);                  }
    void Physics::set_vel(Data& data, glm::vec2 const& vel)          { data.write(2, &vel);                  }
    void Physics::set_inv_mass(Data& data, float inv_mass)           { data.write(3, &inv_mass);             }
    void Physics::set_rot_vel(Data& data, float rot_vel)             { data.write(4, &rot_vel);              }

    void Physics::update(Data& data, float delta_time) {
        // Get the transform on this entity.
        Data* transform = data.get_entity()->get_data()[0];
        glm::vec2 temp = Transform::get_pos(*transform);
        
        set_old_pos(data, temp);
        set_vel(data, get_acc(data) * delta_time + get_vel(data));

        temp = get_vel(data) * delta_time + Transform::get_pos(*transform);

        Transform::set_rot(*transform, Transform::get_rot(*transform) + get_rot_vel(data) * delta_time);
        Transform::set_pos(*transform, temp);
    }
}
