// Contains data for a transform.
// Contains functions to get and set transform information.

#pragma once
#include "glm/vec2.hpp"

namespace Engine {
    class DataManager;
    class Data;
    // 0: glm::vec2 position
    // 1: float     rotation
    // 2: glm::vec2 scale
    // 3: matrix    transform
    // 4: int is    dirty

    class Transform {
        public:
            // Creates a new transform data on the heap.
            static Data* New(glm::vec2 const&, float, glm::vec2 const&);

            // Getters.
            static glm::vec2 const& get_pos(Data const&);
            static float const&     get_rot(Data const&);
            static glm::vec2 const& get_scal(Data const&);

            // Setters.
            static void set_pos(Data&, glm::vec2 const&);
            static void set_rot(Data&, float);
            static void set_scal(Data&, glm::vec2 const&);

        private:
            static DataManager* manager;
    };
}
