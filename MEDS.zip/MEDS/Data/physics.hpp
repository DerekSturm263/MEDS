// Contains data for an object's physics.
// Contains the start, update, and exit functions for physics.

#pragma once
#include "glm/vec2.hpp"

namespace Engine {
    class DataManager;
    class Data;
    // 0: glm::vec2 old_position
    // 1: glm::vec2 acceleration
    // 2: glm::vec2 velocity
    // 3: float     inverse mass
    // 4: float     rotational velocity

    class Physics {
        public:
            // Creates a new physics data on the heap.
            static Data* New();

            // Getters.
            static glm::vec2 const& get_old_pos(Data const&);
            static glm::vec2 const& get_acc(Data const&);
            static glm::vec2 const& get_vel(Data const&);
            static float const&     get_inv_mass(Data const&);
            static float const&     get_rot_vel(Data const&);

            // Setters.
            static void set_old_pos(Data&, glm::vec2 const&);
            static void set_acc(Data&, glm::vec2 const&);
            static void set_vel(Data&, glm::vec2 const&);
            static void set_inv_mass(Data&, float);
            static void set_rot_vel(Data&, float);

        private:
            static DataManager* manager;

            // Loop functions.
            static void update(Data&, float);
    };
}
