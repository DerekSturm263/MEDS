#include "renderer.hpp"
#include "transform.hpp"
#include "../Entities/data.hpp"
#include "../Entities/entity.hpp"
#include "../Systems/graphics.hpp"
#include "../Systems/debug.hpp"
#include "../Managers/data_manager.hpp"

namespace Engine {
    DataManager* Renderer::manager = nullptr;

    Data* Renderer::New() {
        if (!manager) {
            manager = new DataManager(1, nullptr, update, nullptr);
        }

        Data* data = new Data(0, nullptr);
        manager->add_data(data);
        return data;
    }

    void Renderer::update(Data& data, float delta_time) {
        // Get the transform on this entity.
        Data* transform = data.get_entity()->get_data()[0];
        
        // Draw a rectangle at the transform's position.
        Graphics::draw_rect(Transform::get_pos(*transform),
                            Transform::get_scal(*transform),
                            glm::vec4(1, 0.5, 0.5, 1));
    }
}
