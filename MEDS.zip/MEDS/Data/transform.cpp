#include "transform.hpp"
#include "../Entities/data.hpp"
#include "../Managers/data_manager.hpp"

namespace Engine {
    DataManager* Transform::manager = nullptr;

    Data* Transform::New(glm::vec2 const& pos, float rot, glm::vec2 const& scal) {
        if (!manager) {
            manager = new DataManager(0, nullptr, nullptr, nullptr);
        }
            
        Data* data = new Data(3, &pos, &rot, &scal);
        manager->add_data(data);
        return data;
    }

    glm::vec2 const&    Transform::get_pos(Data const& data)       { return *(glm::vec2*)  data.read(0);   }
    float const&        Transform::get_rot(Data const& data)       { return *(float*)      data.read(1);   }
    glm::vec2 const&    Transform::get_scal(Data const& data)      { return *(glm::vec2*)  data.read(2);   }

    void Transform::set_pos(Data& data, glm::vec2 const& pos)      { data.write(0, &pos);                  }
    void Transform::set_rot(Data& data, float rot)                 { data.write(1, &rot);                  }
    void Transform::set_scal(Data& data, glm::vec2 const& scal)    { data.write(2, &scal);                 }
}
