#include "movement.hpp"
#include "physics.hpp"
#include "../Entities/data.hpp"
#include "../Entities/entity.hpp"
#include "../Systems/input.hpp"
#include "../Systems/debug.hpp"
#include "../Managers/data_manager.hpp"

namespace Engine {
    DataManager* Movement::manager = nullptr;

    Data* Movement::New() {
        if (!manager) {
            manager = new DataManager(0, nullptr, update, nullptr);
        }

        Data* data = new Data(0, nullptr);
        manager->add_data(data);
        return data;
    }

    void Movement::update(Data& data, float delta_time) {
        // Get the physics on this entity.
        Data* physics = data.get_entity()->get_data()[1];
        
        switch (Input::get_key_hold()) {
            case 'w':
                Physics::set_acc(*physics, glm::vec2(0, 5));
                break;

            case 'a':
                Physics::set_acc(*physics, glm::vec2(-2, 0));
                break;

            case 'd':
                Physics::set_acc(*physics, glm::vec2(2, 0));
                break;
        }
    }
}
