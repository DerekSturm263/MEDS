#include "input.hpp"

namespace Engine {
    unsigned char   Input::last_key_pressed = 0;
    int             Input::last_button_pressed = 0;
    unsigned char   Input::is_mouse_up, Input::is_mouse_down = 0;
    int             Input::last_x = 0, Input::last_y = 0;

    void Input::keyboard_callback(unsigned char key, int x, int y) {
        last_key_pressed = key;
    }

    void Input::keyboard_up_callback(unsigned char key, int x, int y) {
        last_key_pressed = 0;
    }

    void Input::mouse_callback(int button, int state, int x, int y) {
        last_button_pressed = button;
        is_mouse_up = state == 0x0001;
        is_mouse_down = state == 0x0000;
    }

    void Input::mouse_passive_callback(int x, int y) {
        last_x = x;
        last_y = y;
    }

    unsigned char Input::get_key_down() {
        return last_key_pressed && is_mouse_down;
    }

    unsigned char Input::get_key_hold() {
        return last_key_pressed;
    }

    unsigned char Input::get_key_up() {
        return last_key_pressed && is_mouse_up;
    }

    int Input::get_button_down() {
        return last_button_pressed;
    }

    int Input::get_button_hold() {
        return last_button_pressed;
    }

    int Input::get_button_up() {
        return last_button_pressed;
    }

    int Input::get_mouse_x() {
        return last_x;
    }

    int Input::get_mouse_y() {
        return last_y;
    }
}
