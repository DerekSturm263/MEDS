#pragma once

namespace Engine {
    class Input {
        public:
            // Gets the key pressed this frame.
            static unsigned char get_key_down();

            // Gets the key currently being held.
            static unsigned char get_key_hold();

            // Gets the key being released this frame.
            static unsigned char get_key_up();

            // Gets the mouse button pressed this frame.
            static int get_button_down();

            // Gets the mouse button currently being held.
            static int get_button_hold();

            // Gets the mouse button released this frame.
            static int get_button_up();

            // Gets the mouse's x position.
            static int get_mouse_x();

            // Gets the mouse's y position.
            static int get_mouse_y();

        private:
            static unsigned char    last_key_pressed;
            static int              last_button_pressed;
            static unsigned char    is_mouse_up, is_mouse_down;
            static int              last_x, last_y;

            // Callback for pressing a key.
            static void keyboard_callback(unsigned char, int, int);

            // Callback for releasing a key.
            static void keyboard_up_callback(unsigned char, int, int);

            // Callback for pressing a mouse button.
            static void mouse_callback(int, int, int, int);

            // Callback for not pressing a mouse button.
            static void mouse_passive_callback(int, int);

            friend class Engine;
    };
}
