#pragma once

class GLFWwindow;

namespace Engine {
    class Engine {
        public:
            // Start the engine loop.
            static int start(int, char*[]);

        private:
            static const unsigned int window_width;
            static const unsigned int window_height;

            // Update the engine.
            static int update(GLFWwindow*);

            // Shutdown the engine.
            static int shutdown();

            // Callback function for resizing the window.
            static void framebuffer_size_callback(GLFWwindow*, int, int);
    };
}
