#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include "glm/vec2.hpp"
#include "engine.hpp"
#include "graphics.hpp"
#include "input.hpp"
#include "debug.hpp"
#include "../Managers/thread_manager.hpp"
#include "../Managers/scene_manager.hpp"
#include "../Entities/scene.hpp"

#include "../Managers/data_manager.hpp"
#include "../Managers/data_thread.hpp"
#include "../Entities/data.hpp"
#include "../Entities/entity.hpp"
#include "../Data/renderer.hpp"
#include "../Data/transform.hpp"
#include "../Data/physics.hpp"
#include "../Data/movement.hpp"

namespace Engine {
    const unsigned int Engine::window_width = 1280;
    const unsigned int Engine::window_height = 720;

    int Engine::start(int argc, char* argv[]) {
        Debug::init();
        Debug::log("Initialized Engine.");
        ThreadManager::init();

        glfwInit();
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#if DEBUG
        glfwWindowHint(GLFW_OPENGL_DEBUG_CONTEXT, GLFW_TRUE);
#endif

        GLFWwindow* window = glfwCreateWindow(window_width, window_height, "EDS V1.0", nullptr, nullptr);
        if (!window) {
            Debug::log("Window could not be created.");
            glfwTerminate();
            return -1;
        }

        glfwMakeContextCurrent(window);

        if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
            Debug::log("Failed to initialize GLAD.");
            return -1;
        }

        glViewport(0, 0, window_width, window_height);
        glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

        Graphics::init();

        Scene* scene = nullptr;

        if (argv[1]) {
            scene = Scene::from_file(argv[1]);
        } else {
            Entity* player  = new Entity(4, Transform::New(glm::vec2(-0.5, 0), 0, glm::vec2(0.1, 0.1)),
                                            Physics::New(),
                                            Renderer::New(), 
                                            Movement::New());

            /*Entity* enemy   = new Entity(3, Transform::New(glm::vec2(0.5, 0), 0, glm::vec2(0.1, 0.1)),
                                            Physics::New(),
                                            Renderer::New());*/

            scene = new Scene(1, player);
        }
        SceneManager::load_scene(scene);
        ThreadManager::start();

        return update(window);
    }

    int Engine::update(GLFWwindow* window) {
        while (!glfwWindowShouldClose(window)) {
            Graphics::clear();
            ThreadManager::update();

            glfwSwapBuffers(window);
            glfwPollEvents();    
        }

        return shutdown();
    }

    int Engine::shutdown() {
        ThreadManager::exit();
        SceneManager::unload_scene();

        Graphics::shutdown();
        ThreadManager::shutdown();

        glfwTerminate();

        Debug::log("Shutdown Engine.");
        Debug::shutdown();

        return 0;
    }

    void Engine::framebuffer_size_callback(GLFWwindow* window, int width, int height) {
        glViewport(0, 0, width, height);
    }
}
