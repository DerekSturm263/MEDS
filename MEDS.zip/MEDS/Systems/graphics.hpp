#pragma once
#include <vector>
#include "glm/vec2.hpp"
#include "glm/vec4.hpp"

typedef float GLfloat;
typedef unsigned int GLenum;
typedef unsigned long size_t;

namespace Engine {
    class Graphics {
        public:
            // Draws a rectangle on the screen.
            static void draw_rect(glm::vec2 const&, glm::vec2 const&, glm::vec4 const&);

        private:
            static unsigned int shader_program;

            // Initialize the graphics system.
            static void init();

            // Shutdown the graphics system.
            static void shutdown();

            // Clear all graphics on the window.
            static void clear();

            // Create a new shader.
            static int create_shader(const char*, GLenum);

            // Create a new shader from a file.
            static int shader_from_file(const char*);

            // Create a new shader program.
            static unsigned int create_program(size_t, int...);

            friend class Engine;
    };
}
