#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include "graphics.hpp"
#include "debug.hpp"

namespace Engine {
    unsigned int Graphics::shader_program = 0;

    void Graphics::draw_rect(glm::vec2 const& pos, glm::vec2 const& scale, glm::vec4 const& color) {
        float vertices[12] = {
            pos.x + scale.x * 0.5f,     pos.y + scale.y * 0.5f,     0.0f,
            pos.x + scale.x * 0.5f,     pos.y + scale.y * -0.5f,    0.0f,
            pos.x + scale.x * -0.5f,    pos.y + scale.y * -0.5f,    0.0f,
            pos.x + scale.x * -0.5f,    pos.y + scale.y * 0.5f,     0.0f
        };
        unsigned int indices[6] = {
            0, 1, 3,
            1, 2, 3
        };

        unsigned int VBO, VAO, EBO;
        glGenVertexArrays(1, &VAO);
        glGenBuffers(1, &VBO);
        glGenBuffers(1, &EBO);
        glBindVertexArray(VAO);

        glBindBuffer(GL_ARRAY_BUFFER, VBO);
        glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_DYNAMIC_DRAW);

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_DYNAMIC_DRAW);

        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
        glEnableVertexAttribArray(0);

        glBindBuffer(GL_ARRAY_BUFFER, 0);

        glUseProgram(shader_program);
        glBindVertexArray(VAO);
        glDrawElements(GL_TRIANGLES, sizeof(indices) / sizeof(*indices), GL_UNSIGNED_INT, 0);
        glBindVertexArray(0);
    }

    void Graphics::init() {
        // Initialize the shaders.
        unsigned int vertex_shader      = shader_from_file("./Assets/Shaders/vertex.vert");
        unsigned int fragment_shader    = shader_from_file("./Assets/Shaders/fragment.frag");

        // Create the shader program and use it.
        shader_program = create_program(2, vertex_shader, fragment_shader);

        // Delete the shaders.
        Debug::log("Shader %d deleted", vertex_shader);
        glDeleteShader(vertex_shader);
        Debug::log("Shader %d deleted", fragment_shader);
        glDeleteShader(fragment_shader);

        // Set the polygon mode.
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    }

    void Graphics::shutdown() {
        if (shader_program) {
            Debug::log("Shader Program %d destroyed.", shader_program);
            glDeleteProgram(shader_program);
        }
    }

    void Graphics::clear() {
        glClearColor(1, 1, 1, 1);
        glClear(GL_COLOR_BUFFER_BIT);
    }

    int Graphics::shader_from_file(const char* file_name) {
        // Get the shaders from files.
        FILE* file = fopen(file_name, "r"); 
        char* source = nullptr;
        int offset = 0;
        
        if (file) {
            char buffer[512] = { 0 };

            // Copy the contents of the file to a buffer.
            while (!feof(file)) {
                char* temp = fgets(buffer + offset, sizeof(buffer), file);
                offset += strlen(temp);
            }

            source = buffer;
            fclose(file);
        }

        // Check the file extension.
        const char* extension = file_name + strlen(file_name) - 4;
        if (strncmp(extension, "vert", 4) == 0) {
            return create_shader(source, GL_VERTEX_SHADER);
        } else if (strncmp(extension, "frag", 4) == 0) {
            return create_shader(source, GL_FRAGMENT_SHADER);
        }
        
        return 0;
    }

    int Graphics::create_shader(const char* source, GLenum type) {
        unsigned int shader = glCreateShader(type);
        glShaderSource(shader, 1, &source, nullptr);
        glCompileShader(shader);

        int success;
        glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
        if(!success) {
            char log_buffer[256] = { 0 };
            glGetShaderInfoLog(shader, sizeof(log_buffer), nullptr, log_buffer);
            Debug::log("Shader could not be compiled: %s", log_buffer);
            return 0;
        }

        Debug::log("Shader %d compiled.", shader);
        return shader;
    }

    unsigned int Graphics::create_program(size_t count, int shader...) {
        unsigned int program = glCreateProgram();

        va_list vl;
        va_start(vl, shader);

        int val = shader;
        for (unsigned int i = 0; i < count; ++i) {
            glAttachShader(program, val);
            val = va_arg(vl, int);
        }
        va_end(vl);

        glLinkProgram(program);

        int success;
        glGetProgramiv(program, GL_LINK_STATUS, &success);
        if(!success) {
            char log_buffer[256] = { 0 };
            glGetProgramInfoLog(program, sizeof(log_buffer), nullptr, log_buffer);
            Debug::log("Shader Program could not be linked: %s", log_buffer);
            return 0;
        }

        Debug::log("Shader Program %d created.", program);
        return program;
    }
}
