#pragma once
#include <stdio.h>

#define DEBUG 1

namespace Engine {
    class Debug {
        public:
            // Send a message to the debug file.
            static void log(const char*...);

        private:
            static const char*  file_name;
            static FILE*        debug_file;

            // Initialize the debug system.
            static void init();

            // Shutdown the debug system.
            static void shutdown();

            friend class Engine;
    };
}
