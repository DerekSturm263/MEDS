#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "debug.hpp"

namespace Engine {
    const char* Debug::file_name = "debug_log.txt";
    FILE*       Debug::debug_file = nullptr;

    void Debug::log(const char* format_string...) {
        if (!debug_file)
            return;

#if DEBUG
        va_list vl;
	    va_start(vl, format_string);

        char buffer[512] = { 0 };
	    for (const char* c = format_string; *c != '\0'; ++c) {
            char buffer2[256] = { 0 };

            if (*c == '%') {
                switch (*(++c)) {
				    case 's': // String.
                        sprintf(buffer2, "%s", va_arg(vl, const char*));
					    break;
				    case 'f': // Float.
                        sprintf(buffer2, "%f", va_arg(vl, double));
					    break;
				    case 'd': // Decimal.
                        sprintf(buffer2, "%d", va_arg(vl, int));
					    break;
				    case 'i': // Int.
                        sprintf(buffer2, "%i", va_arg(vl, int));
					    break;
				    case 'p': // Pointer.
                        sprintf(buffer2, "%p", va_arg(vl, void*));
					    break;
			    }
            } else {
                buffer2[0] = *c;
            }

            strcat(buffer, buffer2);
        }
	    va_end(vl);

        strcat(buffer, "\n");
        fprintf(debug_file, buffer);
        fprintf(stdout, buffer);
#endif
    }

    void Debug::init() {
        debug_file = fopen(file_name, "wt");

        if (!debug_file) {
            printf("%s could not be opened or created.", file_name);
        }

        log("Initialized Debug System.");
    }

    void Debug::shutdown() {
        if (!debug_file)
            return;

        log("Shutdown Debug System.");
        fclose(debug_file);
    }
}
