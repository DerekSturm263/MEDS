#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include "scene.hpp"
#include "entity.hpp"
#include "../Systems/debug.hpp"

namespace Engine {
    Scene::Scene(size_t size, Entity* const& entity...) : _all_entities(std::vector<Entity*>()) {
        // Check if any default inputs are given.
        if (entity) {
            // Create and start a va_list.
            va_list vl;
            va_start(vl, entity);
    
            // Iterate and add all given values until nullptr is hit.
            Entity* val = entity;
            for (unsigned int i = 0; i < size; ++i) {
                add_entity(val);
                val = va_arg(vl, Entity*);
            }
    
            // End the va_list.
            va_end(vl);
        }

        Debug::log("Scene created.");
    }

    Scene::~Scene() {
        // Delete all entities in the scene.
        for (unsigned int i = 0; i < _all_entities.size(); ++i) {
            delete _all_entities[i];
            _all_entities[i] = nullptr;
        }

        Debug::log("Scene destroyed.");
    }

    void Scene::add_entity(Entity* const& entity) {
        if (!entity)
            return;

        // Add to the list.
        _all_entities.push_back(entity);
    }

    void Scene::remove_entity(Entity* const& entity) {
        if (!entity)
            return;


    }

    Scene* Scene::from_file(const char* file_path) {
        if (!file_path)
            return nullptr;

        FILE* open = fopen(file_path, "r");
        if (!open)
            return nullptr;

        Scene* scene = new Scene(0, nullptr);

        while (!feof(open)) {
            char buffer[64] = { 0 };
            fgets(buffer, sizeof(buffer), open);
            Entity* entity = Entity::from_file(buffer);
            scene->add_entity(entity);
        }

        fclose(open);
        return scene;
    }
}
