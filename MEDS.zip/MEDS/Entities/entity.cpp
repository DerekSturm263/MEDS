#include <stdio.h>
#include <stdarg.h>
#include "entity.hpp"
#include "data.hpp"
#include "../Managers/data_manager.hpp"
#include "../Managers/entity_data_map.hpp"
#include "../Systems/debug.hpp"

namespace Engine {
    unsigned int Entity::next_id = 0;

    Entity::Entity(size_t size, Data* const& data...) : _id(next_id++) {
        // Check if any default inputs are given.
        if (data) {
            // Create and start a va_list.
            va_list vl;
            va_start(vl, data);
    
            // Iterate and add all given values until nullptr is hit.
            Data* val = data;
            for (unsigned int i = 0; i < size; ++i) {
                link_data(val);
                val = va_arg(vl, Data*);
            }
    
            // End the va_list.
            va_end(vl);
        }

        EntityDataMap::add_entity(_id, this);

        Debug::log("Entity %d created.", _id);
    }

    Entity::~Entity() {
        EntityDataMap::remove_entity(_id, this);

        Debug::log("Entity %d destroyed.", _id);
    }

    void Entity::link_data(Data* const& data) {
        if (!data)
            return;

        data->_id = _id;
        EntityDataMap::add_data(_id, data);
    }

    void Entity::unlink_data(Data* const& data) {
        if (!data)
            return;

        data->_id = -1;
        EntityDataMap::remove_data(_id, data);
    }

    std::vector<Data*> const& Entity::get_data() const {
        return EntityDataMap::get_data(this);
    }

    Entity* Entity::from_file(const char* file_path) {
        if (!file_path)
            return nullptr;

        FILE* open = fopen(file_path, "r");
        if (!open)
            return nullptr;

        Entity* entity = new Entity(0, 0, nullptr);

        while (!feof(open)) {
            char buffer[64] = { 0 };
            fgets(buffer, sizeof(buffer), open);
            Data* data = Data::from_file(buffer);
            entity->link_data(data);
        }

        fclose(open);
        return entity;
    }
}
