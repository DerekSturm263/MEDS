// Contains data that can be read or written to.
// Can be typedeffed to create new data types.

#pragma once

typedef unsigned long size_t;

namespace Engine {
    class Entity;
    
    class Data {
        public:
            Data(size_t, void const* const&...);
            Data(Data const&);
            ~Data();

            // Writes data to a data.
            void write(unsigned int, void const*);

            // Reads data from a data.
            void const* read(unsigned int) const;

            // Retrieves linked entity from the data.
            Entity* const& get_entity() const;

            // Creates a data from a file.
            static Data* from_file(const char*);

        private:
            int     _id;
            void**  _buffer;
            size_t  _size;

            friend class Entity;
            friend class EntityDataMap;
    };
}
