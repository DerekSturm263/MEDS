#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "data.hpp"
#include "entity.hpp"
#include "../Managers/data_manager.hpp"
#include "../Managers/entity_data_map.hpp"
#include "../Systems/debug.hpp"

namespace Engine {
    Data::Data(size_t size, void const* const& buffer...) : _id(-1), _buffer(new void*[size]), _size(size) {
        // Check if any default inputs are given.
        if (buffer) {
            // Create and start a va_list.
            va_list vl;
            va_start(vl, buffer);

            // Iterate and add all given values until nullptr is hit.
            void const* val = buffer;
            for (unsigned int i = 0; i < size; ++i) {
                write(i, val);
                val = va_arg(vl, void*);
            }

            // End the va_list.
            va_end(vl);
        }

        Debug::log("Data created.");
    }

    Data::Data(Data const& data) : _buffer(new void*[data._size]), _size(data._size)  {
        // Copy the contents of data to the new data.
        memcpy(_buffer, data._buffer, _size);

        Debug::log("Data created as deep copy.");
    }

    Data::~Data() {
        // Free the buffer.
        delete[] _buffer;

        Debug::log("Data destroyed.");
    }

    void Data::write(unsigned int offset, void const* to_write) {
        if (!to_write)
            return;

        // Copy the bytes from to_write into the data.
        memcpy(_buffer + offset, to_write, sizeof(void*));
    }

    void const* Data::read(unsigned int offset) const {
        // Return starting from the offset.
        return _buffer + offset;
    }

    Entity* const& Data::get_entity() const {
        return EntityDataMap::get_entity(this);
    }

    Data* Data::from_file(const char* file_path) {
        if (!file_path)
            return nullptr;

        FILE* open = fopen(file_path, "r");
        if (!open)
            return nullptr;

        size_t data_size = 0;
        void** data_buf = nullptr;
        while (!feof(open)) {
            ++data_size;
            data_buf = (void**)realloc(data_buf, data_size * sizeof(void*));

            char buffer[64] = { 0 };
            fgets(buffer, sizeof(buffer), open);
            data_buf[data_size - 1] = (void*)buffer;
        }

        Data* data = new Data(data_size, data_buf);

        free(data_buf);
        fclose(open);
        return data;
    }
}
