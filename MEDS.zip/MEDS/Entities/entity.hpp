// Contains an id used to index data from the entity.
// ID is used with a hashmap to get which data belongs to this entity.

#pragma once
#include <vector>

typedef unsigned long size_t;

namespace Engine {
    class Data;
    class DataManager;

    class Entity {
        public:
            Entity(size_t, Data* const&...);
            ~Entity();
            
            // Adds existing data to an entity.
            void link_data(Data* const&);

            // Removes existing data from an entity.
            void unlink_data(Data* const&);

            // Retrieves linked data from the entity.
            std::vector<Data*> const& get_data() const;

            // Creates an entity from a file.
            static Entity* from_file(const char*);

        private:
            unsigned int _id;

            static unsigned int next_id;

            friend class EntityDataMap;
    };
}
