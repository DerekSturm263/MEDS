// Contains entities.
// Can be swapped in and out to change scenes.

#pragma once
#include <vector>

typedef unsigned long size_t;

namespace Engine {
    class Entity;

    class Scene {
        public:
            Scene(size_t, Entity* const&...);
            ~Scene();

            // Adds an existing entity to a scene.
            void add_entity(Entity* const&);

            // Removes an existing entity from a scene.
            void remove_entity(Entity* const&);

            // Creates a scene from a file.
            static Scene* from_file(const char*);

        private:
            std::vector<Entity*> _all_entities;
    };
}
