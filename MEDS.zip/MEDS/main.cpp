#include "Systems/engine.hpp"

int main(int argc, char* argv[]) {
    return Engine::Engine::start(argc, argv);
}
