#include <stdio.h>
#include "scene_manager.hpp"
#include "../Entities/scene.hpp"

namespace Engine {
    Scene* SceneManager::current_scene = nullptr;

    Scene* const& SceneManager::load_scene(Scene* const& scene) {
        unload_scene();
        
        current_scene = scene;
        return current_scene;
    }

    void SceneManager::unload_scene() {
        if (!current_scene)
            return;
            
        delete current_scene;
    }
}
