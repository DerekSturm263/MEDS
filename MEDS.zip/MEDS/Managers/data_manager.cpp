#include <stdlib.h>
#include "data_manager.hpp"
#include "../Entities/data.hpp"
#include "../Systems/debug.hpp"
#include "data_thread.hpp"

namespace Engine {
    DataManager::DataManager(unsigned int thread_num, data_fn start, data_float_fn update, data_fn exit) : _all_data(std::vector<Data*>()), _start_fn(start), _update_fn(update), _exit_fn(exit) {
        DataThread::add_to_data_thread(thread_num, this);
        
        Debug::log("Data Manager created.");
    }

    DataManager::~DataManager() {
        // Delete all the data on the data manager.
        for (unsigned int i = 0; i < _all_data.size(); ++i) {
            delete _all_data[i];
            _all_data[i] = nullptr;
        }

        Debug::log("Data Manager destroyed.");
    }

    void DataManager::add_data(Data* const& data) {
        if (!data)
            return;
            
        // Add to the list.
        _all_data.push_back(data);
    }

    void DataManager::remove_data(Data* const& data) {
        if (!data)
            return;
          
        
    }

    void DataManager::start() const {
        if (!_start_fn)
            return;

        // Iterate through all the data and execute the start functions.
        for (unsigned int i = 0; i < _all_data.size(); ++i) {
            _start_fn(*_all_data[i]);
        }
    }

    void DataManager::update(float delta_time) const {
        if (!_update_fn)
            return;

        // Iterate through all the data and execute the update functions.
        for (unsigned int i = 0; i < _all_data.size(); ++i) {
            _update_fn(*_all_data[i], delta_time);
        }
    }

    void DataManager::exit() const {
        if (!_exit_fn)
            return;

        // Iterate through all the data and execute the exit functions.
        for (unsigned int i = 0; i < _all_data.size(); ++i) {
            _exit_fn(*_all_data[i]);
        }
    }
}
