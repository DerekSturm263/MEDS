#include <stdlib.h>
#include <stdarg.h>
#include <pthread.h>
#include "data_thread.hpp"
#include "data_manager.hpp"
#include "thread_manager.hpp"
#include "../Systems/debug.hpp"

namespace Engine {
    std::vector<DataThread*> DataThread::all_data_threads;

    DataThread::DataThread(size_t size, DataManager* const& data_manager...) : _all_data_managers(std::vector<DataManager*>()) {
        // Check if any default inputs are given.
        if (data_manager) {
            // Create and start a va_list.
            va_list vl;
            va_start(vl, data_manager);
    
            // Iterate and add all given values until nullptr is hit.
            DataManager* val = data_manager;
            for (unsigned int i = 0; i < size; ++i) {
                add_data_manager(val);
                val = va_arg(vl, DataManager*);
            }
    
            // End the va_list.
            va_end(vl);
        }

        ThreadManager::add_data_thread(this);

        Debug::log("Data Thread created.");
    }
    
    DataThread::~DataThread() {
        // Delete all the data managers on the data thread.
        for (unsigned int i = 0; i < _all_data_managers.size(); ++i) {
            delete _all_data_managers[i];
            _all_data_managers[i] = nullptr;
        }

        Debug::log("Data Thread destroyed.");
    }
    
    void DataThread::add_data_manager(DataManager* const& data_manager) {
        if (!data_manager)
            return;

        // Add to the list.
        _all_data_managers.push_back(data_manager);
    }
    
    void DataThread::remove_data_manager(DataManager* const& data_manager) {
        if (!data_manager)
            return;


    }
    
    void DataThread::add_to_data_thread(unsigned int index, DataManager* const& data_manager) {
        if (!data_manager)
            return;

        if (index >= all_data_threads.size()) {
            // Add to the list.
            all_data_threads.push_back(new DataThread(1, data_manager));
        } else {
            // Edit the list.
            all_data_threads[index]->add_data_manager(data_manager);
        }
    }

    void* DataThread::start(void* data) {
        if (!data)
            return nullptr;

        // Convert the argument into data.
        DataThread* data_thread = (DataThread*)data;

        // Iterate through all the data managers and execute their data.
        for (unsigned int i = 0; i < data_thread->_all_data_managers.size(); ++i) {
            data_thread->_all_data_managers[i]->start();
        }
    
        // Exit the thread this data thread is on.
        pthread_exit(nullptr);
        return nullptr;
    }
    
    void* DataThread::update(void* data) {
        if (!data)
            return nullptr;

        // Convert the argument into data.
        DataThread* data_thread = (DataThread*)data;

        // Iterate through all the data managers and execute their data.
        for (unsigned int i = 0; i < data_thread->_all_data_managers.size(); ++i) {
            data_thread->_all_data_managers[i]->update(0.016F);
        }
    
        // Exit the thread this data thread is on.
        pthread_exit(nullptr);
        return nullptr;
    }
    
    void* DataThread::exit(void* data) {
        if (!data)
            return nullptr;
            
        // Convert the argument into data.
        DataThread* data_thread = (DataThread*)data;

        // Iterate through all the data managers and execute their data.
        for (unsigned int i = 0; i < data_thread->_all_data_managers.size(); ++i) {
            data_thread->_all_data_managers[i]->exit();
        }
    
        // Exit the thread this data thread is on.
        pthread_exit(nullptr);
        return nullptr;
    }
}
