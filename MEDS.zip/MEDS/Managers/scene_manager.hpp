// Manages information about the current scene and functions for loading scenes.

#pragma once

namespace Engine {
    class Scene;

    class SceneManager {
        public:
            // Loads a scene from a file path.
            static Scene* const& load_scene(Scene* const&);

            // Unloads the currently loaded scene.
            static void unload_scene();

        private:
            static Scene* current_scene;

            friend class Engine;
    };
}
