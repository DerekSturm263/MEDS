// Contains a list of data threads and their corresponding IDs.
// Manages the threads and executes the start, update, and exit functions for them.

#pragma once
#include <vector>

typedef unsigned long size_t;
typedef unsigned long pthread_t;

namespace Engine {
    class DataThread;

    class ThreadManager {
        private:
            std::vector<DataThread*>    _all_data_threads;
            std::vector<pthread_t>      _tids;

            static ThreadManager*   instance;

            ThreadManager(size_t, DataThread* const&...);
            ~ThreadManager();

            // Adds an existing data thread to a data manager.
            static void add_data_thread(DataThread* const&);

            // Removes an existing data thread from a data manager.
            static void remove_data_thread(DataThread* const&);

            // Initialize the Thread Manager.
            static void init();

            // Shutdown the Thread Manager.
            static void shutdown();

            // Execute all start functions on the data thread in the thread manager.
            static void start();

            // Execute all update functions on the data thread in the thread manager.
            static void update();

            // Execute all exit functions on the data thread in the thread manager.
            static void exit();

            friend class Engine;
            friend class DataThread;
    };
}
