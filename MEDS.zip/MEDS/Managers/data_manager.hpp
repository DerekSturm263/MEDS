// Contains a list of all data of a single type.
// Executes the start, update, and exit functions on that data.

#pragma once
#include <vector>

typedef unsigned long size_t;

namespace Engine {
    class Data;

    class DataManager {
        public:
            typedef void(*data_fn)(Data&);
            typedef void(*data_float_fn)(Data&, float);

            DataManager(unsigned int, data_fn, data_float_fn, data_fn);
            ~DataManager();

            // Adds an existing data to a data manager.
            void add_data(Data* const&);

            // Removes an existing data from a data manager.
            void remove_data(Data* const&);

        private:
            std::vector<Data*>  _all_data;
    
            data_fn             _start_fn;
            data_float_fn       _update_fn;
            data_fn             _exit_fn;

            // Execute all start functions on the data in the data manager.
            void start() const;

            // Execute all update functions on the data in the data manager.
            void update(float) const;

            // Execute all exit functions on the data in the data manager.
            void exit() const;

            friend class DataThread;
            friend class Entity;
    };
}
