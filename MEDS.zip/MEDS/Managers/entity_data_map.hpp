#pragma once
#include <map>
#include <vector>

namespace Engine {
    class Data;
    class Entity;

    class EntityDataMap {
        private:
            static std::map<unsigned int, std::vector<Data*>> data_map;
            static std::map<unsigned int, Entity*>            entity_map;

            // Add a data to the data map.
            static void add_data(unsigned int, Data* const&);

            // Remove a data from the data map.
            static void remove_data(unsigned int, Data* const&);

            // Add an entity to the entity map.
            static void add_entity(unsigned int, Entity* const&);

            // Remove an entity from the entity map.
            static void remove_entity(unsigned int, Entity* const&);

            // Get the array of data attached to the entity.
            static std::vector<Data*>& get_data(Entity const* const&);

            // Get the entity that owns the data.
            static Entity* const& get_entity(Data const* const&);

            friend class Data;
            friend class Entity;
    };
}
