#include "entity_data_map.hpp"
#include "../Entities/entity.hpp"
#include "../Entities/data.hpp"

namespace Engine {
    std::map<unsigned int, std::vector<Data*>>    EntityDataMap::data_map;
    std::map<unsigned int, Entity*>               EntityDataMap::entity_map;

    void EntityDataMap::add_data(unsigned int index, Data* const& data) {
        if (index > data_map.size()) {
            data_map.insert({ index, std::vector<Data*>() });
        }

        data_map[index].push_back(data);
    }

    void EntityDataMap::remove_data(unsigned int index, Data* const& data) {
        data_map.erase(index);
    }

    void EntityDataMap::add_entity(unsigned int index, Entity* const& entity) {
        entity_map.insert({ index, entity });
    }

    void EntityDataMap::remove_entity(unsigned int index, Entity* const& entity) {
        entity_map.erase(index);
    }

    std::vector<Data*>& EntityDataMap::get_data(Entity const* const& entity) {
        return data_map[entity->_id];
    }

    Entity* const& EntityDataMap::get_entity(Data const* const& data) {
        return entity_map[data->_id];
    }
}
