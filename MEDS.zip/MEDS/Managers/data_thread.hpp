// Contains a list of data managers on the same thread.
// Executes the start, update, and exit functions on those data managers.

#pragma once
#include <vector>

typedef unsigned long size_t;

namespace Engine {
    class DataManager;

    class DataThread {
        private:
            std::vector<DataManager*> _all_data_managers;

            static std::vector<DataThread*> all_data_threads;

            DataThread(size_t, DataManager* const&...);
            ~DataThread();

            // Adds an existing data manager to a data thread.
            void add_data_manager(DataManager* const&);

            // Removes an existing data manager from a data thread.
            void remove_data_manager(DataManager* const&);

            // Adds a data manager to a data thread and creates one if neccessary.
            static void add_to_data_thread(unsigned int, DataManager* const&);

            // Execute all functions on the data managers in the data thread.
            static void* start(void*);

            // Execute all functions on the data managers in the data thread.
            static void* update(void*);

            // Execute all functions on the data managers in the data thread.
            static void* exit(void*);

            friend class ThreadManager;
            friend class DataManager;
    };
}
