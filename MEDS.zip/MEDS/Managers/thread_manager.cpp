#include <stdlib.h>
#include <stdarg.h>
#include <pthread.h>
#include "thread_manager.hpp"
#include "data_thread.hpp"
#include "../Systems/debug.hpp"

namespace Engine {
    ThreadManager* ThreadManager::instance = nullptr;

    void ThreadManager::init() {
        if (instance)
            return;

        Debug::log("Initialized Thread Manager.");

        instance = new ThreadManager(0, nullptr);
    }

    void ThreadManager::shutdown() {
        if (!instance)
            return;
        
        delete instance;

        Debug::log("Shutdown Thread Manager.");
    }

    ThreadManager::ThreadManager(size_t size, DataThread* const& data_thread...) : _all_data_threads(std::vector<DataThread*>()), _tids(std::vector<pthread_t>()) {        
        // Check if any default inputs are given.
        if (data_thread) {
            // Create and start a va_list.
            va_list vl;
            va_start(vl, data_thread);

            // Iterate and add all given values until nullptr is hit.
            DataThread* val = data_thread;
            for (unsigned int i = 0; i < size; ++i) {
                add_data_thread(val);
                val = va_arg(vl, DataThread*);
            }

            // End the va_list.
            va_end(vl);
        }

        Debug::log("Thread Manager created.");
    }

    ThreadManager::~ThreadManager() {
        // Delete all the data threads on the thread manager.
        for (unsigned int i = 0; i < _all_data_threads.size(); ++i) {
            delete _all_data_threads[i];
            _all_data_threads[i] = nullptr;
        }

        Debug::log("Thread Manager destroyed.");
    }

    void ThreadManager::add_data_thread(DataThread* const& data_thread) {
        if (!instance || !data_thread)
            return;

        // Increase the size of the data manager list.
        instance->_all_data_threads.push_back(data_thread);
        instance->_tids.push_back(0);
    }

    void ThreadManager::remove_data_thread(DataThread* const& data_thread) {
        if (!instance || !data_thread)
            return;
            
        
    }
    
    void ThreadManager::start() {
        if (!instance)
            return;

        // Create a thread for each thread manager.
        for (unsigned int i = 0; i < instance->_all_data_threads.size(); ++i) {
            pthread_create(&instance->_tids[i], nullptr, DataThread::start, instance->_all_data_threads[i]);
        }

        // Wait for all threads to finish executing before returning.
        for (unsigned int i = 0; i < instance->_tids.size(); ++i) {
            pthread_join(instance->_tids[i], nullptr);
        }
    }

    void ThreadManager::update() {
        if (!instance)
            return;

        // Create a thread for each thread manager.
        for (unsigned int i = 0; i < instance->_all_data_threads.size(); ++i) {
            pthread_create(&instance->_tids[i], nullptr, DataThread::update, instance->_all_data_threads[i]);
        }

        // Wait for all threads to finish executing before returning.
        for (unsigned int i = 0; i < instance->_tids.size(); ++i) {
            pthread_join(instance->_tids[i], nullptr);
        }
    }

    void ThreadManager::exit() {
        if (!instance)
            return;
            
        // Create a thread for each thread manager.
        for (unsigned int i = 0; i < instance->_all_data_threads.size(); ++i) {
            pthread_create(&instance->_tids[i], nullptr, DataThread::exit, instance->_all_data_threads[i]);
        }

        // Wait for all threads to finish executing before returning.
        for (unsigned int i = 0; i < instance->_tids.size(); ++i) {
            pthread_join(instance->_tids[i], nullptr);
        }
    }
}
